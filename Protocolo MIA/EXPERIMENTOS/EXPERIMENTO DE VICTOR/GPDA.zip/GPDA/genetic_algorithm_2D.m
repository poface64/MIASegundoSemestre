function stats = genetic_algorithm_2D(database)
    output_folder = 'images';
    if ~exist(output_folder, 'dir')
        mkdir(output_folder);
    end

    % Leer datos de la base de datos
    D = readmatrix(database);
    features = D(:, 1:end-1);
    labels = D(:, end-1);
    [m, n] = size(D);
    classes = unique(labels);
    num_classes = numel(classes);
    n = n - 1;

    % Dividir en entrenamiento y validación
    train_data = [];
    test_data = [];
    train_ratio = 0.7;
    for i = 1:num_classes
        class = classes(i);
        class_indices = find(labels == class);
        num_samples = numel(class_indices);
        num_train_samples = round(train_ratio * num_samples);
        shuffled_indices = class_indices(randperm(num_samples));
        train_indices = shuffled_indices(1:num_train_samples);
        test_indices = shuffled_indices(num_train_samples + 1:end);
        train_data = [train_data; D(train_indices, :)];
        test_data = [test_data; D(test_indices, :)];
    end

    % Parámetros del algoritmo genético
    num_executions = 30;
    num_generations = 1600;
    num_parents = 10;
    num_matrices = 250;
    mutation_probability = 0.09;

    % Ejecutar el algoritmo genético
    all_populations = cell(1, num_executions);
    all_plots = cell(1, num_executions);
    for execution = 1:num_executions
        disp("ejecucion " + execution)
        plot_line = [];
        population(num_matrices) = struct('matrix', [], 'fitness', 0);

        for i = 1:num_matrices
            population(i).matrix = generate_basis2(n);
            population(i).fitness = silhouetteFitness(train_data, population(i).matrix);
        end

        [~, idx] = sort([population.fitness], 'descend');
        population = population(idx);

        for generation = 1:num_generations
            parent_indices = stochastic_universal_sampling(population, 2 * num_parents);
            for i = 1:2:num_parents*2
                parent1 = population(parent_indices(i)).matrix;
                parent2 = population(parent_indices(i+1)).matrix;
                [child1, child2] = crossover2(parent1, parent2);
                mutant1 = mutate3(child1, mutation_probability);
                mutant2 = mutate3(child2, mutation_probability);
                child1_fitness = silhouetteFitness(train_data, mutant1);
                child2_fitness = silhouetteFitness(train_data, mutant2);
                population(end+1).matrix = mutant1;
                population(end).fitness = child1_fitness;
                population(end+1).matrix = mutant2;
                population(end).fitness = child2_fitness;
            end

            [~, idx] = sort([population.fitness], 'descend');
            population = population(idx);
            population = population(1:end-(2*num_parents));
            plot_line = [plot_line, population(1).fitness];
        end
        all_populations{execution} = population;
        all_plots{execution} = plot_line;
    end

    % Estadísticas
    best_fitnesses = zeros(1, num_executions);
    for i = 1:num_executions
        best_fitnesses(i) = all_populations{i}(1).fitness;
    end

    [~, idx_max] = max(best_fitnesses);
    [~, idx_min] = min(best_fitnesses);
    sorted_fitnesses = sort(best_fitnesses);
    median_fitness = sorted_fitnesses(ceil(num_executions / 2));
    original_idx_median = find(best_fitnesses == median_fitness, 1, 'first');
    stats = table(mean(best_fitnesses), std(best_fitnesses), ...
                  best_fitnesses(idx_max), best_fitnesses(idx_min), ...
                  median_fitness, ...
                  'VariableNames', {'Mean', 'StdDev', 'MaxFitness', 'MinFitness', 'MedianFitness'});
    
    writetable(stats, database + "_stats_2D.csv")

    figure;
    plot(all_plots{idx_max}, 'k-', 'LineWidth', 2, 'DisplayName', 'Max'); 
    hold on;
    plot(all_plots{idx_min}, 'k--', 'LineWidth', 1.5, 'DisplayName', 'Min');
    plot(all_plots{original_idx_median}, 'k-.', 'LineWidth', 1.5, 'DisplayName', 'Median'); 
    grid on;
    legend('show', 'Location', 'best'); 
    title("Convergence graph for " + database, 'Interpreter', 'none'); 

    saveas(gcf, fullfile(output_folder, database + "_convergence.png"));
    close;

    % scatter_plot_2d(all_populations{1, original_idx_median}(1).matrix, D, 'Projected Space ' + database);
    % saveas(gcf, fullfile(output_folder, database + "_scatter.png"));
    % close;

    DA = D(:, 1:end-1) * all_populations{1, original_idx_median}(1).matrix;
    DA = [DA labels];
    csvwrite("GPDA_2D_" + database + ".csv", DA);
end
