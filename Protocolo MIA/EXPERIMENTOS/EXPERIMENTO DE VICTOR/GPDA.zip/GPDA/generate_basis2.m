function matrix = generate_basis2(n)
    % Genera la primera columna con números aleatorios entre -8 y 8
    col1 = -8 + (16 * rand(n, 1));
    
    col2_temp = -8 + (16 * rand(n, 1));  % Vector temporal aleatorio
    col2 = col2_temp - (dot(col2_temp, col1) / dot(col1, col1)) * col1;
    
    % Combinar las columnas en una matriz n x 2
    matrix = [col1, col2];
end