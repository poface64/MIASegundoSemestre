function [child1, child2] = crossover2(parent1, parent2)
    [rows, cols] = size(parent1);
    if ~isequal(size(parent1), size(parent2))
        error('Los padres deben tener las mismas dimensiones.');
    end
    
    % Inicializar los hijos
    child1 = zeros(rows, cols);
    child2 = zeros(rows, cols);
    
    % Itera sobre cada columna
    for col = 1:cols
        if rows > 1
            cut = randi([1, rows-1]);
        else
            cut = 1; 
        end
        
        % Intercambia las coordenadas hasta el punto de corte
        child1(1:cut, col) = parent1(1:cut, col);
        child1(cut+1:end, col) = parent2(cut+1:end, col);
        
        child2(1:cut, col) = parent2(1:cut, col);
        child2(cut+1:end, col) = parent1(cut+1:end, col);
    end
    
    % Asegurar que los hijos tengan columnas ortogonales
    child1 = repare2(child1);
    child2 = repare2(child2);
end
